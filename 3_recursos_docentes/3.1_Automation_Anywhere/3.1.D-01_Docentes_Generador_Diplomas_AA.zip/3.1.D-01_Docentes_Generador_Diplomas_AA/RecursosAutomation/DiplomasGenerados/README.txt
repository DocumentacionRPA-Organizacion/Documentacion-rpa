DiplomasGenerados
=================

Esta carpeta está vacía a propósito.

Es la carpeta de salida del ejercicio: aquí deben guardarse los diplomas
(archivos .docx) que genera el bot cuando lo ejecutas.

- Debe existir antes de ejecutar el bot.
- Su ruta debe coincidir con la que asignaste a la variable CarpetaSalida
  (por ejemplo: C:\RecursosAutomation\DiplomasGenerados\).
- Al terminar, esta carpeta (con los diplomas generados) forma parte de
  tu entrega.

Puedes borrar este archivo README.txt si lo prefieres.
